"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "@/components/ui/calendar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Users,
  CalendarIcon,
  Pill,
  CreditCard,
  Bed,
  Bell,
  Activity,
  UserPlus,
  Search,
  Filter,
  MoreHorizontal,
  Phone,
  Clock,
  CheckCircle,
  XCircle,
  Moon,
  Sun,
} from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
} from "recharts"
import type { DateRange } from "react-day-picker"
import { addDays, format } from "date-fns"
import { CalendarDays, Download, RefreshCw, X } from "lucide-react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Checkbox } from "@/components/ui/checkbox"
import { Separator } from "@/components/ui/separator"
import { useTheme } from "next-themes"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

function ThemeToggle() {
  const { theme, setTheme } = useTheme()

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={() => setTheme(theme === "light" ? "dark" : "light")}
      className="h-9 w-9"
    >
      <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
      <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
      <span className="sr-only">Toggle theme</span>
    </Button>
  )
}

export default function ChellaHMS() {
  const [activeTab, setActiveTab] = useState("dashboard")
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())

  // Analytics state management
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: addDays(new Date(), -30),
    to: new Date(),
  })
  const [selectedDepartments, setSelectedDepartments] = useState<string[]>([
    "Cardiology",
    "Pediatrics",
    "Orthopedics",
    "Emergency",
    "Surgery",
  ])
  const [selectedInsuranceProviders, setSelectedInsuranceProviders] = useState<string[]>([
    "NHIS",
    "Private Insurance",
    "Corporate",
    "Self Pay",
  ])
  const [selectedMetrics, setSelectedMetrics] = useState<string[]>(["revenue", "patients", "satisfaction", "occupancy"])
  const [isFilterOpen, setIsFilterOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  // Filter options
  const departmentOptions = [
    "Cardiology",
    "Pediatrics",
    "Orthopedics",
    "Emergency",
    "Surgery",
    "Radiology",
    "Laboratory",
  ]
  const insuranceOptions = ["NHIS", "Private Insurance", "Corporate", "Self Pay", "International"]
  const metricOptions = [
    { id: "revenue", label: "Revenue" },
    { id: "patients", label: "Patient Volume" },
    { id: "satisfaction", label: "Satisfaction" },
    { id: "occupancy", label: "Bed Occupancy" },
    { id: "pharmacy", label: "Pharmacy Sales" },
    { id: "claims", label: "Insurance Claims" },
  ]

  // Filter handlers
  const handleDepartmentToggle = (department: string) => {
    setSelectedDepartments((prev) =>
      prev.includes(department) ? prev.filter((d) => d !== department) : [...prev, department],
    )
  }

  const handleInsuranceToggle = (provider: string) => {
    setSelectedInsuranceProviders((prev) =>
      prev.includes(provider) ? prev.filter((p) => p !== provider) : [...prev, provider],
    )
  }

  const handleMetricToggle = (metric: string) => {
    setSelectedMetrics((prev) => (prev.includes(metric) ? prev.filter((m) => m !== metric) : [...prev, metric]))
  }

  const handleRefreshData = () => {
    setIsLoading(true)
    // Simulate API call
    setTimeout(() => setIsLoading(false), 1000)
  }

  const handleExportData = () => {
    // Export functionality
    console.log("Exporting data with filters:", {
      dateRange,
      departments: selectedDepartments,
      insurance: selectedInsuranceProviders,
      metrics: selectedMetrics,
    })
  }

  const clearAllFilters = () => {
    setSelectedDepartments(departmentOptions)
    setSelectedInsuranceProviders(insuranceOptions)
    setSelectedMetrics(metricOptions.map((m) => m.id))
    setDateRange({
      from: addDays(new Date(), -30),
      to: new Date(),
    })
  }

  // Mock data
  const dashboardStats = [
    { title: "Total Patients", value: "2,847", icon: Users, change: "+12%" },
    { title: "Today's Appointments", value: "24", icon: CalendarIcon, change: "+3%" },
    { title: "Available Beds", value: "18/45", icon: Bed, change: "-2 beds" },
    { title: "Pending Bills", value: "₦1.2M", icon: CreditCard, change: "+8%" },
  ]

  const recentAppointments = [
    { id: 1, patient: "Jane Doe", doctor: "Dr. Smith", time: "09:00", status: "confirmed", type: "Consultation" },
    { id: 2, patient: "John Okafor", doctor: "Dr. Johnson", time: "10:30", status: "pending", type: "Follow-up" },
    { id: 3, patient: "Mary Adebayo", doctor: "Dr. Williams", time: "11:00", status: "completed", type: "Check-up" },
    {
      id: 4,
      patient: "Ahmed Hassan",
      doctor: "Dr. Brown",
      time: "14:00",
      status: "cancelled",
      type: "Surgery Consult",
    },
  ]

  const patients = [
    { id: "P12345", name: "Jane Doe", age: 34, gender: "Female", phone: "+234 801 234 5678", lastVisit: "2024-01-15" },
    { id: "P12346", name: "John Okafor", age: 45, gender: "Male", phone: "+234 802 345 6789", lastVisit: "2024-01-10" },
    {
      id: "P12347",
      name: "Mary Adebayo",
      age: 28,
      gender: "Female",
      phone: "+234 803 456 7890",
      lastVisit: "2024-01-12",
    },
  ]

  const medications = [
    { id: 1, name: "Paracetamol 500mg", category: "Analgesic", stock: 450, reorderLevel: 100, supplier: "PharmaCorp" },
    { id: 2, name: "Amoxicillin 250mg", category: "Antibiotic", stock: 75, reorderLevel: 50, supplier: "MediSupply" },
    { id: 3, name: "Lisinopril 10mg", category: "ACE Inhibitor", stock: 200, reorderLevel: 80, supplier: "HealthPlus" },
  ]

  // Analytics mock data
  const patientDemographics = [
    { ageGroup: "0-18", count: 245, percentage: 15 },
    { ageGroup: "19-35", count: 567, percentage: 35 },
    { ageGroup: "36-50", count: 423, percentage: 26 },
    { ageGroup: "51-65", count: 298, percentage: 18 },
    { ageGroup: "65+", count: 97, percentage: 6 },
  ]

  const monthlyRevenue = [
    { month: "Jan", revenue: 2400000, expenses: 1800000, profit: 600000 },
    { month: "Feb", revenue: 2100000, expenses: 1700000, profit: 400000 },
    { month: "Mar", revenue: 2800000, expenses: 1900000, profit: 900000 },
    { month: "Apr", revenue: 2600000, expenses: 1850000, profit: 750000 },
    { month: "May", revenue: 3200000, expenses: 2000000, profit: 1200000 },
    { month: "Jun", revenue: 2900000, expenses: 1950000, profit: 950000 },
  ]

  const appointmentTrends = [
    { day: "Mon", scheduled: 45, completed: 42, cancelled: 3, noShow: 2 },
    { day: "Tue", scheduled: 52, completed: 48, cancelled: 2, noShow: 2 },
    { day: "Wed", scheduled: 38, completed: 35, cancelled: 1, noShow: 2 },
    { day: "Thu", scheduled: 61, completed: 55, cancelled: 4, noShow: 2 },
    { day: "Fri", scheduled: 49, completed: 44, cancelled: 3, noShow: 2 },
    { day: "Sat", scheduled: 28, completed: 26, cancelled: 1, noShow: 1 },
    { day: "Sun", scheduled: 15, completed: 14, cancelled: 0, noShow: 1 },
  ]

  const departmentPerformance = [
    { department: "Cardiology", patients: 156, revenue: 890000, satisfaction: 4.8 },
    { department: "Pediatrics", patients: 234, revenue: 567000, satisfaction: 4.9 },
    { department: "Orthopedics", patients: 189, revenue: 1200000, satisfaction: 4.6 },
    { department: "Emergency", patients: 445, revenue: 780000, satisfaction: 4.4 },
    { department: "Surgery", patients: 78, revenue: 1500000, satisfaction: 4.7 },
  ]

  const bedOccupancyTrend = [
    { date: "2024-01-01", occupancy: 75, available: 25 },
    { date: "2024-01-02", occupancy: 78, available: 22 },
    { date: "2024-01-03", occupancy: 82, available: 18 },
    { date: "2024-01-04", occupancy: 79, available: 21 },
    { date: "2024-01-05", occupancy: 85, available: 15 },
    { date: "2024-01-06", occupancy: 88, available: 12 },
    { date: "2024-01-07", occupancy: 83, available: 17 },
  ]

  const pharmacyMetrics = [
    { category: "Antibiotics", dispensed: 1250, revenue: 450000 },
    { category: "Analgesics", dispensed: 2100, revenue: 320000 },
    { category: "Cardiovascular", dispensed: 890, revenue: 780000 },
    { category: "Diabetes", dispensed: 567, revenue: 890000 },
    { category: "Respiratory", dispensed: 445, revenue: 234000 },
  ]

  const insuranceClaims = [
    { provider: "NHIS", claims: 145, approved: 132, pending: 8, rejected: 5, amount: 2400000 },
    { provider: "Private Insurance", claims: 89, approved: 78, pending: 6, rejected: 5, amount: 1800000 },
    { provider: "Corporate", claims: 67, approved: 61, pending: 4, rejected: 2, amount: 1200000 },
    { provider: "Self Pay", claims: 234, approved: 234, pending: 0, rejected: 0, amount: 890000 },
  ]

  const chartConfig = {
    revenue: {
      label: "Revenue",
      color: "hsl(var(--chart-1))",
    },
    expenses: {
      label: "Expenses",
      color: "hsl(var(--chart-2))",
    },
    profit: {
      label: "Profit",
      color: "hsl(var(--chart-3))",
    },
    scheduled: {
      label: "Scheduled",
      color: "hsl(var(--chart-1))",
    },
    completed: {
      label: "Completed",
      color: "hsl(var(--chart-2))",
    },
    cancelled: {
      label: "Cancelled",
      color: "hsl(var(--chart-3))",
    },
    occupancy: {
      label: "Occupancy",
      color: "hsl(var(--chart-1))",
    },
    available: {
      label: "Available",
      color: "hsl(var(--chart-2))",
    },
  }

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"]

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "confirmed":
        return (
          <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">
            <CheckCircle className="w-3 h-3 mr-1" />
            Confirmed
          </Badge>
        )
      case "pending":
        return (
          <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300">
            <Clock className="w-3 h-3 mr-1" />
            Pending
          </Badge>
        )
      case "completed":
        return (
          <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300">
            <CheckCircle className="w-3 h-3 mr-1" />
            Completed
          </Badge>
        )
      case "cancelled":
        return (
          <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300">
            <XCircle className="w-3 h-3 mr-1" />
            Cancelled
          </Badge>
        )
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Activity className="h-8 w-8 text-blue-600 dark:text-blue-400" />
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Chelal HMS</h1>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <ThemeToggle />
            <Button variant="ghost" size="icon">
              <Bell className="h-5 w-5" />
            </Button>
            
            {/* User Profile Modal */}
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="ghost" className="h-10 w-10 rounded-full p-0">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Dr. Admin" />
                    <AvatarFallback className="bg-blue-600 dark:bg-blue-500 text-white text-sm font-medium">
                      DR
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md dark:bg-gray-800 dark:border-gray-700">
                <DialogHeader>
                  <DialogTitle className="text-gray-900 dark:text-white">User Profile</DialogTitle>
                  <DialogDescription className="text-gray-600 dark:text-gray-300">
                    Account information and settings
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-6">
                  {/* Profile Picture and Basic Info */}
                  <div className="flex items-center space-x-4">
                    <Avatar className="h-16 w-16">
                      <AvatarImage src="/placeholder.svg?height=64&width=64" alt="Dr. Admin" />
                      <AvatarFallback className="bg-blue-600 dark:bg-blue-500 text-white text-lg font-medium">
                        DR
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Dr. Admin</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-300">Hospital Administrator</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">admin@chelalhms.com</p>
                    </div>
                  </div>
                  
                  <Separator className="dark:bg-gray-600" />
                  
                  {/* User Details */}
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-sm font-medium text-gray-900 dark:text-white">Employee ID</Label>
                        <p className="text-sm text-gray-600 dark:text-gray-300">EMP001</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-gray-900 dark:text-white">Department</Label>
                        <p className="text-sm text-gray-600 dark:text-gray-300">Administration</p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-sm font-medium text-gray-900 dark:text-white">Phone</Label>
                        <p className="text-sm text-gray-600 dark:text-gray-300">+234 801 234 5678</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-gray-900 dark:text-white">Extension</Label>
                        <p className="text-sm text-gray-600 dark:text-gray-300">2001</p>
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium text-gray-900 dark:text-white">Last Login</Label>
                      <p className="text-sm text-gray-600 dark:text-gray-300">Today at 8:30 AM</p>
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium text-gray-900 dark:text-white">Status</Label>
                      <div className="flex items-center space-x-2 mt-1">
                        <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                        <span className="text-sm text-gray-600 dark:text-gray-300">Active</span>
                      </div>
                    </div>
                  </div>
                  
                  <Separator className="dark:bg-gray-600" />
                  
                  {/* Action Buttons */}
                  <div className="flex flex-col space-y-2">
                    <Button variant="outline" className="w-full justify-start">
                      <Users className="mr-2 h-4 w-4" />
                      Edit Profile
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Bell className="mr-2 h-4 w-4" />
                      Notification Settings
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Activity className="mr-2 h-4 w-4" />
                      Activity Log
                    </Button>
                    <Separator className="dark:bg-gray-600" />
                    <Button variant="destructive" className="w-full justify-start">
                      <XCircle className="mr-2 h-4 w-4" />
                      Sign Out
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 min-h-screen">
          <nav className="p-4 space-y-2">
            <Button
              variant={activeTab === "dashboard" ? "default" : "ghost"}
              className="w-full justify-start hover:bg-gray-100 dark:hover:bg-gray-700"
              onClick={() => setActiveTab("dashboard")}
            >
              <Activity className="mr-2 h-4 w-4" />
              Dashboard
            </Button>
            <Button
              variant={activeTab === "patients" ? "default" : "ghost"}
              className="w-full justify-start hover:bg-gray-100 dark:hover:bg-gray-700"
              onClick={() => setActiveTab("patients")}
            >
              <Users className="mr-2 h-4 w-4" />
              Patients
            </Button>
            <Button
              variant={activeTab === "appointments" ? "default" : "ghost"}
              className="w-full justify-start hover:bg-gray-100 dark:hover:bg-gray-700"
              onClick={() => setActiveTab("appointments")}
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              Appointments
            </Button>
            <Button
              variant={activeTab === "pharmacy" ? "default" : "ghost"}
              className="w-full justify-start hover:bg-gray-100 dark:hover:bg-gray-700"
              onClick={() => setActiveTab("pharmacy")}
            >
              <Pill className="mr-2 h-4 w-4" />
              Pharmacy
            </Button>
            <Button
              variant={activeTab === "billing" ? "default" : "ghost"}
              className="w-full justify-start hover:bg-gray-100 dark:hover:bg-gray-700"
              onClick={() => setActiveTab("billing")}
            >
              <CreditCard className="mr-2 h-4 w-4" />
              Billing
            </Button>
            <Button
              variant={activeTab === "beds" ? "default" : "ghost"}
              className="w-full justify-start hover:bg-gray-100 dark:hover:bg-gray-700"
              onClick={() => setActiveTab("beds")}
            >
              <Bed className="mr-2 h-4 w-4" />
              Bed Management
            </Button>
            <Button
              variant={activeTab === "analytics" ? "default" : "ghost"}
              className="w-full justify-start hover:bg-gray-100 dark:hover:bg-gray-700"
              onClick={() => setActiveTab("analytics")}
            >
              <Activity className="mr-2 h-4 w-4" />
              Analytics & Reports
            </Button>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6 bg-gray-50 dark:bg-gray-900">
          {activeTab === "dashboard" && (
            <div className="space-y-6">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Dashboard</h2>
                <p className="text-gray-600 dark:text-gray-300">Welcome to Chelal Hospital Management System</p>
              </div>

              {/* Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {dashboardStats.map((stat, index) => (
                  <Card key={index} className="dark:bg-gray-800 dark:border-gray-700">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium text-gray-900 dark:text-white">{stat.title}</CardTitle>
                      <stat.icon className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-gray-900 dark:text-white">{stat.value}</div>
                      <p className="text-xs text-muted-foreground">{stat.change} from last month</p>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Recent Appointments */}
              <Card className="dark:bg-gray-800 dark:border-gray-700">
                <CardHeader>
                  <CardTitle className="text-gray-900 dark:text-white">Today's Appointments</CardTitle>
                  <CardDescription className="text-gray-600 dark:text-gray-300">
                    Recent appointment activity
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Table className="dark:bg-gray-800">
                    <TableHeader>
                      <TableRow className="dark:border-gray-700">
                        <TableHead className="dark:text-gray-300">Patient</TableHead>
                        <TableHead className="dark:text-gray-300">Doctor</TableHead>
                        <TableHead className="dark:text-gray-300">Time</TableHead>
                        <TableHead className="dark:text-gray-300">Type</TableHead>
                        <TableHead className="dark:text-gray-300">Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {recentAppointments.map((appointment) => (
                        <TableRow key={appointment.id} className="dark:border-gray-700 dark:hover:bg-gray-700">
                          <TableCell className="font-medium dark:text-gray-300">{appointment.patient}</TableCell>
                          <TableCell className="dark:text-gray-300">{appointment.doctor}</TableCell>
                          <TableCell className="dark:text-gray-300">{appointment.time}</TableCell>
                          <TableCell className="dark:text-gray-300">{appointment.type}</TableCell>
                          <TableCell className="dark:text-gray-300">{getStatusBadge(appointment.status)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "patients" && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Patients</h2>
                  <p className="text-gray-600 dark:text-gray-300">Manage patient records and information</p>
                </div>
                <Button>
                  <UserPlus className="mr-2 h-4 w-4" />
                  Add Patient
                </Button>
              </div>

              {/* Search and Filter */}
              <div className="flex space-x-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search patients..."
                      className="pl-10 dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                    />
                  </div>
                </div>
                <Button variant="outline">
                  <Filter className="mr-2 h-4 w-4" />
                  Filter
                </Button>
              </div>

              {/* Patients Table */}
              <Card className="dark:bg-gray-800 dark:border-gray-700">
                <CardContent className="p-0">
                  <Table className="dark:bg-gray-800">
                    <TableHeader>
                      <TableRow className="dark:border-gray-700">
                        <TableHead className="dark:text-gray-300">Patient ID</TableHead>
                        <TableHead className="dark:text-gray-300">Name</TableHead>
                        <TableHead className="dark:text-gray-300">Age</TableHead>
                        <TableHead className="dark:text-gray-300">Gender</TableHead>
                        <TableHead className="dark:text-gray-300">Contact</TableHead>
                        <TableHead className="dark:text-gray-300">Last Visit</TableHead>
                        <TableHead className="dark:text-gray-300">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {patients.map((patient) => (
                        <TableRow key={patient.id} className="dark:border-gray-700 dark:hover:bg-gray-700">
                          <TableCell className="font-medium dark:text-gray-300">{patient.id}</TableCell>
                          <TableCell className="dark:text-gray-300">{patient.name}</TableCell>
                          <TableCell className="dark:text-gray-300">{patient.age}</TableCell>
                          <TableCell className="dark:text-gray-300">{patient.gender}</TableCell>
                          <TableCell className="dark:text-gray-300">
                            <div className="flex items-center space-x-1">
                              <Phone className="h-3 w-3" />
                              <span className="text-sm">{patient.phone}</span>
                            </div>
                          </TableCell>
                          <TableCell className="dark:text-gray-300">{patient.lastVisit}</TableCell>
                          <TableCell className="dark:text-gray-300">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent className="dark:bg-gray-800 dark:border-gray-700">
                                <DropdownMenuItem className="dark:text-gray-300 dark:hover:bg-gray-700">
                                  View Details
                                </DropdownMenuItem>
                                <DropdownMenuItem className="dark:text-gray-300 dark:hover:bg-gray-700">
                                  Edit Patient
                                </DropdownMenuItem>
                                <DropdownMenuItem className="dark:text-gray-300 dark:hover:bg-gray-700">
                                  Schedule Appointment
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "appointments" && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Appointments</h2>
                  <p className="text-gray-600 dark:text-gray-300">Schedule and manage patient appointments</p>
                </div>
                <Button>
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  New Appointment
                </Button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Calendar */}
                <Card className="lg:col-span-1 dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-gray-900 dark:text-white">Calendar</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={setSelectedDate}
                      className="rounded-md border dark:bg-gray-800 dark:text-white"
                    />
                  </CardContent>
                </Card>

                {/* Appointment Form */}
                <Card className="lg:col-span-2 dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-gray-900 dark:text-white">Schedule New Appointment</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="patient" className="text-gray-900 dark:text-white">
                          Patient
                        </Label>
                        <Select>
                          <SelectTrigger className="dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                            <SelectValue placeholder="Select patient" />
                          </SelectTrigger>
                          <SelectContent className="dark:bg-gray-800 dark:border-gray-600">
                            <SelectItem value="p1" className="dark:text-white dark:hover:bg-gray-700">
                              Jane Doe (P12345)
                            </SelectItem>
                            <SelectItem value="p2" className="dark:text-white dark:hover:bg-gray-700">
                              John Okafor (P12346)
                            </SelectItem>
                            <SelectItem value="p3" className="dark:text-white dark:hover:bg-gray-700">
                              Mary Adebayo (P12347)
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="doctor" className="text-gray-900 dark:text-white">
                          Doctor
                        </Label>
                        <Select>
                          <SelectTrigger className="dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                            <SelectValue placeholder="Select doctor" />
                          </SelectTrigger>
                          <SelectContent className="dark:bg-gray-800 dark:border-gray-600">
                            <SelectItem value="d1" className="dark:text-white dark:hover:bg-gray-700">
                              Dr. Smith
                            </SelectItem>
                            <SelectItem value="d2" className="dark:text-white dark:hover:bg-gray-700">
                              Dr. Johnson
                            </SelectItem>
                            <SelectItem value="d3" className="dark:text-white dark:hover:bg-gray-700">
                              Dr. Williams
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="date" className="text-gray-900 dark:text-white">
                          Date
                        </Label>
                        <Input
                          type="date"
                          className="dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                        />
                      </div>
                      <div>
                        <Label htmlFor="time" className="text-gray-900 dark:text-white">
                          Time
                        </Label>
                        <Input
                          type="time"
                          className="dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="type" className="text-gray-900 dark:text-white">
                        Appointment Type
                      </Label>
                      <Select>
                        <SelectTrigger className="dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent className="dark:bg-gray-800 dark:border-gray-600">
                          <SelectItem value="consultation" className="dark:text-white dark:hover:bg-gray-700">
                            Consultation
                          </SelectItem>
                          <SelectItem value="followup" className="dark:text-white dark:hover:bg-gray-700">
                            Follow-up
                          </SelectItem>
                          <SelectItem value="checkup" className="dark:text-white dark:hover:bg-gray-700">
                            Check-up
                          </SelectItem>
                          <SelectItem value="surgery" className="dark:text-white dark:hover:bg-gray-700">
                            Surgery Consult
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="notes" className="text-gray-900 dark:text-white">
                        Notes
                      </Label>
                      <Textarea
                        placeholder="Additional notes..."
                        className="dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                      />
                    </div>
                    <Button className="w-full">Schedule Appointment</Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {activeTab === "pharmacy" && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Pharmacy</h2>
                  <p className="text-gray-600 dark:text-gray-300">Manage medication inventory and dispensing</p>
                </div>
                <Button>
                  <Pill className="mr-2 h-4 w-4" />
                  Add Medication
                </Button>
              </div>

              {/* Inventory Overview */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-sm font-medium text-gray-900 dark:text-white">
                      Total Medications
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-gray-900 dark:text-white">1,247</div>
                    <p className="text-xs text-muted-foreground">+5% from last month</p>
                  </CardContent>
                </Card>
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-sm font-medium text-gray-900 dark:text-white">Low Stock Items</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-red-600 dark:text-red-400">12</div>
                    <p className="text-xs text-muted-foreground">Requires attention</p>
                  </CardContent>
                </Card>
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-sm font-medium text-gray-900 dark:text-white">Expired Items</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-orange-600 dark:text-orange-400">3</div>
                    <p className="text-xs text-muted-foreground">Remove from inventory</p>
                  </CardContent>
                </Card>
              </div>

              {/* Medication Inventory */}
              <Card className="dark:bg-gray-800 dark:border-gray-700">
                <CardHeader>
                  <CardTitle className="text-gray-900 dark:text-white">Medication Inventory</CardTitle>
                  <CardDescription className="text-gray-600 dark:text-gray-300">
                    Current stock levels and medication details
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Table className="dark:bg-gray-800">
                    <TableHeader>
                      <TableRow className="dark:border-gray-700">
                        <TableHead className="dark:text-gray-300">Medication</TableHead>
                        <TableHead className="dark:text-gray-300">Category</TableHead>
                        <TableHead className="dark:text-gray-300">Current Stock</TableHead>
                        <TableHead className="dark:text-gray-300">Reorder Level</TableHead>
                        <TableHead className="dark:text-gray-300">Supplier</TableHead>
                        <TableHead className="dark:text-gray-300">Status</TableHead>
                        <TableHead className="dark:text-gray-300">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {medications.map((med) => (
                        <TableRow key={med.id} className="dark:border-gray-700 dark:hover:bg-gray-700">
                          <TableCell className="font-medium dark:text-gray-300">{med.name}</TableCell>
                          <TableCell className="dark:text-gray-300">{med.category}</TableCell>
                          <TableCell className="dark:text-gray-300">{med.stock}</TableCell>
                          <TableCell className="dark:text-gray-300">{med.reorderLevel}</TableCell>
                          <TableCell className="dark:text-gray-300">{med.supplier}</TableCell>
                          <TableCell className="dark:text-gray-300">
                            {med.stock <= med.reorderLevel ? (
                              <Badge variant="destructive">Low Stock</Badge>
                            ) : (
                              <Badge variant="default">In Stock</Badge>
                            )}
                          </TableCell>
                          <TableCell className="dark:text-gray-300">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent className="dark:bg-gray-800 dark:border-gray-700">
                                <DropdownMenuItem className="dark:text-gray-300 dark:hover:bg-gray-700">
                                  Dispense
                                </DropdownMenuItem>
                                <DropdownMenuItem className="dark:text-gray-300 dark:hover:bg-gray-700">
                                  Adjust Stock
                                </DropdownMenuItem>
                                <DropdownMenuItem className="dark:text-gray-300 dark:hover:bg-gray-700">
                                  Reorder
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "billing" && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Billing</h2>
                  <p className="text-gray-600 dark:text-gray-300">Manage patient bills and payments</p>
                </div>
                <Button>
                  <CreditCard className="mr-2 h-4 w-4" />
                  Create Bill
                </Button>
              </div>

              {/* Billing Stats */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-sm font-medium text-gray-900 dark:text-white">Total Revenue</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-gray-900 dark:text-white">₦2.4M</div>
                    <p className="text-xs text-muted-foreground">+12% from last month</p>
                  </CardContent>
                </Card>
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-sm font-medium text-gray-900 dark:text-white">Pending Bills</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-gray-900 dark:text-white">₦1.2M</div>
                    <p className="text-xs text-muted-foreground">45 outstanding bills</p>
                  </CardContent>
                </Card>
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-sm font-medium text-gray-900 dark:text-white">
                      Insurance Claims
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-gray-900 dark:text-white">₦800K</div>
                    <p className="text-xs text-muted-foreground">23 pending claims</p>
                  </CardContent>
                </Card>
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-sm font-medium text-gray-900 dark:text-white">Collection Rate</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-gray-900 dark:text-white">87%</div>
                    <p className="text-xs text-muted-foreground">+3% improvement</p>
                  </CardContent>
                </Card>
              </div>

              {/* Create Bill Form */}
              <Card className="dark:bg-gray-800 dark:border-gray-700">
                <CardHeader>
                  <CardTitle className="text-gray-900 dark:text-white">Create New Bill</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="patient" className="text-gray-900 dark:text-white">
                        Patient
                      </Label>
                      <Select>
                        <SelectTrigger className="dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                          <SelectValue placeholder="Select patient" />
                        </SelectTrigger>
                        <SelectContent className="dark:bg-gray-800 dark:border-gray-600">
                          <SelectItem value="p1" className="dark:text-white dark:hover:bg-gray-700">
                            Jane Doe (P12345)
                          </SelectItem>
                          <SelectItem value="p2" className="dark:text-white dark:hover:bg-gray-700">
                            John Okafor (P12346)
                          </SelectItem>
                        </SelectContent>
                      </div>
                      <div>
                        <Label htmlFor="encounter" className="text-gray-900 dark:text-white">
                          Encounter
                        </Label>
                        <Select>
                          <SelectTrigger className="dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                            <SelectValue placeholder="Select encounter" />
                          </SelectTrigger>
                          <SelectContent className="dark:bg-gray-800 dark:border-gray-600">
                            <SelectItem value="e1" className="dark:text-white dark:hover:bg-gray-700">
                              Consultation - 2024-01-15
                            </SelectItem>
                            <SelectItem value="e2" className="dark:text-white dark:hover:bg-gray-700">
                              Follow-up - 2024-01-10
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  <div>
                    <Label htmlFor="services" className="text-gray-900 dark:text-white">
                      Services
                    </Label>
                    <Select>
                      <SelectTrigger className="dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                        <SelectValue placeholder="Add services" />
                      </SelectTrigger>
                      <SelectContent className="dark:bg-gray-800 dark:border-gray-600">
                        <SelectItem value="consultation" className="dark:text-white dark:hover:bg-gray-700">
                          Consultation - ₦5,000
                        </SelectItem>
                        <SelectItem value="xray" className="dark:text-white dark:hover:bg-gray-700">
                          X-Ray - ₦8,000
                        </SelectItem>
                        <SelectItem value="bloodtest" className="dark:text-white dark:hover:bg-gray-700">
                          Blood Test - ₦3,000
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="insurance" className="text-gray-900 dark:text-white">
                        Insurance
                      </Label>
                      <Select>
                        <SelectTrigger className="dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                          <SelectValue placeholder="Select insurance" />
                        </SelectTrigger>
                        <SelectContent className="dark:bg-gray-800 dark:border-gray-600">
                          <SelectItem value="none" className="dark:text-white dark:hover:bg-gray-700">
                            No Insurance
                          </SelectItem>
                          <SelectItem value="nhis" className="dark:text-white dark:hover:bg-gray-700">
                            NHIS
                          </SelectItem>
                          <SelectItem value="private" className="dark:text-white dark:hover:bg-gray-700">
                            Private Insurance
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="total" className="text-gray-900 dark:text-white">
                        Total Amount
                      </Label>
                      <Input
                        placeholder="₦0.00"
                        className="dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder-gray-400"
                      />
                    </div>
                  </div>
                  <Button className="w-full">Create Bill</Button>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "beds" && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Bed Management</h2>
                  <p className="text-gray-600 dark:text-gray-300">Monitor and manage hospital bed occupancy</p>
                </div>
              </div>

              {/* Bed Occupancy Overview */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-sm font-medium text-gray-900 dark:text-white">Total Beds</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-gray-900 dark:text-white">45</div>
                    <p className="text-xs text-muted-foreground">Across all wards</p>
                  </CardContent>
                </Card>
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-sm font-medium text-gray-900 dark:text-white">Occupied</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-red-600 dark:text-red-400">27</div>
                    <p className="text-xs text-muted-foreground">60% occupancy</p>
                  </CardContent>
                </Card>
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-sm font-medium text-gray-900 dark:text-white">Available</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-green-600 dark:text-green-400">18</div>
                    <p className="text-xs text-muted-foreground">Ready for admission</p>
                  </CardContent>
                </Card>
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-sm font-medium text-gray-900 dark:text-white">Maintenance</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-orange-600 dark:text-orange-400">0</div>
                    <p className="text-xs text-muted-foreground">Under maintenance</p>
                  </CardContent>
                </Card>
              </div>

              {/* Ward Status */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-gray-900 dark:text-white">General Ward</CardTitle>
                    <CardDescription className="text-gray-600 dark:text-gray-300">12/20 beds occupied</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm text-gray-900 dark:text-white">
                        <span>Occupancy</span>
                        <span>60%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-blue-600 h-2 rounded-full" style={{ width: "60%" }}></div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-gray-900 dark:text-white">ICU</CardTitle>
                    <CardDescription className="text-gray-600 dark:text-gray-300">8/10 beds occupied</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm text-gray-900 dark:text-white">
                        <span>Occupancy</span>
                        <span>80%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-red-600 h-2 rounded-full" style={{ width: "80%" }}></div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-gray-900 dark:text-white">Pediatric Ward</CardTitle>
                    <CardDescription className="text-gray-600 dark:text-gray-300">7/15 beds occupied</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm text-gray-900 dark:text-white">
                        <span>Occupancy</span>
                        <span>47%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-green-600 h-2 rounded-full" style={{ width: "47%" }}></div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {activeTab === "analytics" && (
            <div className="space-y-6">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                <div>
                  <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Analytics & Reports</h2>
                  <p className="text-gray-600 dark:text-gray-300">
                    Comprehensive hospital metrics and performance insights
                  </p>
                </div>

                {/* Advanced Filters and Controls */}
                <div className="flex flex-wrap items-center gap-2">
                  {/* Date Range Picker */}
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-auto justify-start text-left font-normal">
                        <CalendarDays className="mr-2 h-4 w-4" />
                        {dateRange?.from ? (
                          dateRange.to ? (
                            <>
                              {format(dateRange.from, "LLL dd, y")} - {format(dateRange.to, "LLL dd, y")}
                            </>
                          ) : (
                            format(dateRange.from, "LLL dd, y")
                          )
                        ) : (
                          <span>Pick a date range</span>
                        )}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0 dark:bg-gray-800 dark:border-gray-600" align="start">
                      <Calendar
                        initialFocus
                        mode="range"
                        defaultMonth={dateRange?.from}
                        selected={dateRange}
                        onSelect={setDateRange}
                        numberOfMonths={2}
                        className="dark:bg-gray-800 dark:text-white"
                      />
                      <div className="p-3 border-t dark:border-gray-600">
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() =>
                              setDateRange({
                                from: addDays(new Date(), -7),
                                to: new Date(),
                              })
                            }
                          >
                            Last 7 days
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() =>
                              setDateRange({
                                from: addDays(new Date(), -30),
                                to: new Date(),
                              })
                            }
                          >
                            Last 30 days
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() =>
                              setDateRange({
                                from: addDays(new Date(), -90),
                                to: new Date(),
                              })
                            }
                          >
                            Last 90 days
                          </Button>
                        </div>
                      </div>
                    </PopoverContent>
                  </Popover>

                  {/* Advanced Filters */}
                  <Popover open={isFilterOpen} onOpenChange={setIsFilterOpen}>
                    <PopoverTrigger asChild>
                      <Button variant="outline">
                        <Filter className="mr-2 h-4 w-4" />
                        Filters
                        {(selectedDepartments.length < departmentOptions.length ||
                          selectedInsuranceProviders.length < insuranceOptions.length ||
                          selectedMetrics.length < metricOptions.length) && (
                          <Badge
                            variant="secondary"
                            className="ml-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs"
                          >
                            !
                          </Badge>
                        )}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-80 dark:bg-gray-800 dark:border-gray-600" align="end">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium text-gray-900 dark:text-white">Advanced Filters</h4>
                          <Button variant="ghost" size="sm" onClick={clearAllFilters}>
                            Clear All
                          </Button>
                        </div>

                        <Separator className="dark:bg-gray-600" />

                        {/* Department Filter */}
                        <div className="space-y-2">
                          <Label className="text-sm font-medium text-gray-900 dark:text-white">Departments</Label>
                          <div className="grid grid-cols-2 gap-2">
                            {departmentOptions.map((dept) => (
                              <div key={dept} className="flex items-center space-x-2">
                                <Checkbox
                                  id={`dept-${dept}`}
                                  checked={selectedDepartments.includes(dept)}
                                  onCheckedChange={() => handleDepartmentToggle(dept)}
                                />
                                <Label htmlFor={`dept-${dept}`} className="text-sm text-gray-900 dark:text-white">
                                  {dept}
                                </Label>
                              </div>
                            ))}
                          </div>
                        </div>

                        <Separator className="dark:bg-gray-600" />

                        {/* Insurance Provider Filter */}
                        <div className="space-y-2">
                          <Label className="text-sm font-medium text-gray-900 dark:text-white">
                            Insurance Providers
                          </Label>
                          <div className="space-y-2">
                            {insuranceOptions.map((provider) => (
                              <div key={provider} className="flex items-center space-x-2">
                                <Checkbox
                                  id={`insurance-${provider}`}
                                  checked={selectedInsuranceProviders.includes(provider)}
                                  onCheckedChange={() => handleInsuranceToggle(provider)}
                                />
                                <Label
                                  htmlFor={`insurance-${provider}`}
                                  className="text-sm text-gray-900 dark:text-white"
                                >
                                  {provider}
                                </Label>
                              </div>
                            ))}
                          </div>
                        </div>

                        <Separator className="dark:bg-gray-600" />

                        {/* Metrics Filter */}
                        <div className="space-y-2">
                          <Label className="text-sm font-medium text-gray-900 dark:text-white">
                            Metrics to Display
                          </Label>
                          <div className="space-y-2">
                            {metricOptions.map((metric) => (
                              <div key={metric.id} className="flex items-center space-x-2">
                                <Checkbox
                                  id={`metric-${metric.id}`}
                                  checked={selectedMetrics.includes(metric.id)}
                                  onCheckedChange={() => handleMetricToggle(metric.id)}
                                />
                                <Label
                                  htmlFor={`metric-${metric.id}`}
                                  className="text-sm text-gray-900 dark:text-white"
                                >
                                  {metric.label}
                                </Label>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </PopoverContent>
                  </Popover>

                  {/* Refresh Button */}
                  <Button variant="outline" onClick={handleRefreshData} disabled={isLoading}>
                    <RefreshCw className={`mr-2 h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
                    Refresh
                  </Button>

                  {/* Export Button */}
                  <Button>
                    <Download className="mr-2 h-4 w-4" />
                    Export
                  </Button>
                </div>
              </div>

              {/* Active Filters Display */}
              {(selectedDepartments.length < departmentOptions.length ||
                selectedInsuranceProviders.length < insuranceOptions.length ||
                selectedMetrics.length < metricOptions.length) && (
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardContent className="pt-4">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-medium text-gray-600 dark:text-gray-300">Active Filters:</span>

                      {selectedDepartments.length < departmentOptions.length && (
                        <div className="flex flex-wrap gap-1">
                          {selectedDepartments.map((dept) => (
                            <Badge key={dept} variant="secondary" className="text-xs">
                              {dept}
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-auto p-0 ml-1"
                                onClick={() => handleDepartmentToggle(dept)}
                              >
                                <X className="h-3 w-3" />
                              </Button>
                            </Badge>
                          ))}
                        </div>
                      )}

                      {selectedInsuranceProviders.length < insuranceOptions.length && (
                        <div className="flex flex-wrap gap-1">
                          {selectedInsuranceProviders.map((provider) => (
                            <Badge key={provider} variant="outline" className="text-xs">
                              {provider}
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-auto p-0 ml-1"
                                onClick={() => handleInsuranceToggle(provider)}
                              >
                                <X className="h-3 w-3" />
                              </Button>
                            </Badge>
                          ))}
                        </div>
                      )}

                      {selectedMetrics.length < metricOptions.length && (
                        <div className="flex flex-wrap gap-1">
                          {selectedMetrics.map((metric) => (
                            <Badge key={metric} variant="default" className="text-xs">
                              {metricOptions.find((m) => m.id === metric)?.label}
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-auto p-0 ml-1"
                                onClick={() => handleMetricToggle(metric)}
                              >
                                <X className="h-3 w-3" />
                              </Button>
                            </Badge>
                          ))}
                        </div>
                      )}

                      <Button variant="ghost" size="sm" onClick={clearAllFilters} className="text-xs">
                        Clear All
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Financial Analytics */}
              {selectedMetrics.includes("revenue") && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card className="dark:bg-gray-800 dark:border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-gray-900 dark:text-white">Revenue & Expenses Trend</CardTitle>
                      <CardDescription className="text-gray-600 dark:text-gray-300">
                        Financial performance from {dateRange?.from ? format(dateRange.from, "MMM dd") : "Start"} to{" "}
                        {dateRange?.to ? format(dateRange.to, "MMM dd, yyyy") : "End"}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ChartContainer config={chartConfig} className="h-[300px] dark:text-white">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={monthlyRevenue}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="month" />
                            <YAxis tickFormatter={(value) => `₦${(value / 1000000).toFixed(1)}M`} />
                            <ChartTooltip
                              content={<ChartTooltipContent />}
                              formatter={(value) => [`₦${(Number(value) / 1000000).toFixed(1)}M`, ""]}
                            />
                            <Bar dataKey="revenue" fill="var(--color-revenue)" />
                            <Bar dataKey="expenses" fill="var(--color-expenses)" />
                            <Bar dataKey="profit" fill="var(--color-profit)" />
                          </BarChart>
                        </ResponsiveContainer>
                      </ChartContainer>
                    </CardContent>
                  </Card>

                  {selectedMetrics.includes("patients") && (
                    <Card className="dark:bg-gray-800 dark:border-gray-700">
                      <CardHeader>
                        <CardTitle className="text-gray-900 dark:text-white">Patient Demographics</CardTitle>
                        <CardDescription className="text-gray-600 dark:text-gray-300">
                          Age distribution of patients in selected period
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <ChartContainer config={chartConfig} className="h-[300px] dark:text-white">
                          <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                              <Pie
                                data={patientDemographics}
                                cx="50%"
                                cy="50%"
                                labelLine={false}
                                label={({ ageGroup, percentage }) => `${ageGroup}: ${percentage}%`}
                                outerRadius={80}
                                fill="#8884d8"
                                dataKey="count"
                              >
                                {patientDemographics.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                              </Pie>
                              <ChartTooltip content={<ChartTooltipContent />} />
                            </PieChart>
                          </ResponsiveContainer>
                        </ChartContainer>
                      </CardContent>
                    </Card>
                  )}
                </div>
              )}

              {/* Department Performance */}
              {selectedMetrics.includes("satisfaction") && (
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-gray-900 dark:text-white">Department Performance</CardTitle>
                    <CardDescription className="text-gray-600 dark:text-gray-300">
                      Performance metrics for selected departments: {selectedDepartments.join(", ")}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table className="dark:bg-gray-800">
                      <TableHeader>
                        <TableRow className="dark:border-gray-700">
                          <TableHead className="dark:text-gray-300">Department</TableHead>
                          <TableHead className="dark:text-gray-300">Patients</TableHead>
                          <TableHead className="dark:text-gray-300">Revenue</TableHead>
                          <TableHead className="dark:text-gray-300">Satisfaction</TableHead>
                          <TableHead className="dark:text-gray-300">Performance</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {departmentPerformance
                          .filter((dept) => selectedDepartments.includes(dept.department))
                          .map((dept) => (
                            <TableRow key={dept.department} className="dark:border-gray-700 dark:hover:bg-gray-700">
                              <TableCell className="font-medium dark:text-gray-300">{dept.department}</TableCell>
                              <TableCell className="dark:text-gray-300">{dept.patients}</TableCell>
                              <TableCell className="dark:text-gray-300">
                                ₦{(dept.revenue / 1000000).toFixed(1)}M
                              </TableCell>
                              <TableCell className="dark:text-gray-300">
                                <div className="flex items-center space-x-1">
                                  <span>{dept.satisfaction}</span>
                                  <div className="flex">
                                    {[...Array(5)].map((_, i) => (
                                      <span
                                        key={i}
                                        className={`text-xs ${i < Math.floor(dept.satisfaction) ? "text-yellow-400" : "text-gray-300"}`}
                                      >
                                        ★
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell className="dark:text-gray-300">
                                <div className="w-full bg-gray-200 rounded-full h-2">
                                  <div
                                    className="bg-green-600 h-2 rounded-full"
                                    style={{ width: `${(dept.satisfaction / 5) * 100}%` }}
                                  ></div>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              )}

              {/* Insurance Claims Analysis */}
              {selectedMetrics.includes("claims") && (
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-gray-900 dark:text-white">Insurance Claims Analysis</CardTitle>
                    <CardDescription className="text-gray-600 dark:text-gray-300">
                      Claims data for selected providers: {selectedInsuranceProviders.join(", ")}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table className="dark:bg-gray-800">
                      <TableHeader>
                        <TableRow className="dark:border-gray-700">
                          <TableHead className="dark:text-gray-300">Provider</TableHead>
                          <TableHead className="dark:text-gray-300">Total Claims</TableHead>
                          <TableHead className="dark:text-gray-300">Approved</TableHead>
                          <TableHead className="dark:text-gray-300">Pending</TableHead>
                          <TableHead className="dark:text-gray-300">Rejected</TableHead>
                          <TableHead className="dark:text-gray-300">Approval Rate</TableHead>
                          <TableHead className="dark:text-gray-300">Amount</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {insuranceClaims
                          .filter((claim) => selectedInsuranceProviders.includes(claim.provider))
                          .map((claim) => (
                            <TableRow key={claim.provider} className="dark:border-gray-700 dark:hover:bg-gray-700">
                              <TableCell className="font-medium dark:text-gray-300">{claim.provider}</TableCell>
                              <TableCell className="dark:text-gray-300">{claim.claims}</TableCell>
                              <TableCell className="dark:text-gray-300">
                                <Badge variant="default">{claim.approved}</Badge>
                              </TableCell>
                              <TableCell className="dark:text-gray-300">
                                <Badge variant="secondary">{claim.pending}</Badge>
                              </TableCell>
                              <TableCell className="dark:text-gray-300">
                                <Badge variant="destructive">{claim.rejected}</Badge>
                              </TableCell>
                              <TableCell className="dark:text-gray-300">
                                <div className="flex items-center space-x-2">
                                  <span>{((claim.approved / claim.claims) * 100).toFixed(1)}%</span>
                                  <div className="w-16 bg-gray-200 rounded-full h-2">
                                    <div
                                      className="bg-green-600 h-2 rounded-full"
                                      style={{ width: `${(claim.approved / claim.claims) * 100}%` }}
                                    ></div>
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell className="dark:text-gray-300">
                                ₦{(claim.amount / 1000000).toFixed(1)}M
                              </TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              )}

              {/* Operational Metrics */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-gray-900 dark:text-white">Bed Occupancy Trend</CardTitle>
                    <CardDescription className="text-gray-600 dark:text-gray-300">
                      Daily bed utilization over the past week
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ChartContainer config={chartConfig} className="h-[300px] dark:text-white">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={bedOccupancyTrend}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="date" tickFormatter={(value) => new Date(value).toLocaleDateString()} />
                          <YAxis />
                          <ChartTooltip
                            content={<ChartTooltipContent />}
                            labelFormatter={(value) => new Date(value).toLocaleDateString()}
                          />
                          <Line type="monotone" dataKey="occupancy" stroke="var(--color-occupancy)" strokeWidth={2} />
                          <Line type="monotone" dataKey="available" stroke="var(--color-available)" strokeWidth={2} />
                        </LineChart>
                      </ResponsiveContainer>
                    </ChartContainer>
                  </CardContent>
                </Card>

                <Card className="dark:bg-gray-800 dark:border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-gray-900 dark:text-white">Pharmacy Performance</CardTitle>
                    <CardDescription className="text-gray-600 dark:text-gray-300">
                      Medication dispensing by category
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ChartContainer config={chartConfig} className="h-[300px] dark:text-white">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={pharmacyMetrics} layout="horizontal">
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis type="number" tickFormatter={(value) => `₦${(value / 1000).toFixed(0)}K`} />
                          <YAxis dataKey="category" type="category" width={100} />
                          <ChartTooltip
                            content={<ChartTooltipContent />}
                            formatter={(value) => [`₦${(Number(value) / 1000).toFixed(0)}K`, ""]}
                          />
                          <Bar dataKey="revenue" fill="#8884d8" />
                        </BarChart>
                      </ResponsiveContainer>
                    </ChartContainer>
                  </CardContent>
                </Card>
              </div>

              {/* Insurance Claims Analysis */}
              <Card className="dark:bg-gray-800 dark:border-gray-700">
                <CardHeader>
                  <CardTitle className="text-gray-900 dark:text-white">Insurance Claims Analysis</CardTitle>
                  <CardDescription className="text-gray-600 dark:text-gray-300">
                    Claims processing and approval rates by provider
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Table className="dark:bg-gray-800">
                    <TableHeader>
                      <TableRow className="dark:border-gray-700">
                        <TableHead className="dark:text-gray-300">Provider</TableHead>
                        <TableHead className="dark:text-gray-300">Total Claims</TableHead>
                        <TableHead className="dark:text-gray-300">Approved</TableHead>
                        <TableHead className="dark:text-gray-300">Pending</TableHead>
                        <TableHead className="dark:text-gray-300">Rejected</TableHead>
                        <TableHead className="dark:text-gray-300">Approval Rate</TableHead>
                        <TableHead className="dark:text-gray-300">Amount</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {insuranceClaims.map((claim) => (
                        <TableRow key={claim.provider} className="dark:border-gray-700 dark:hover:bg-gray-700">
                          <TableCell className="font-medium dark:text-gray-300">{claim.provider}</TableCell>
                          <TableCell className="dark:text-gray-300">{claim.claims}</TableCell>
                          <TableCell className="dark:text-gray-300">
                            <Badge variant="default">{claim.approved}</Badge>
                          </TableCell>
                          <TableCell className="dark:text-gray-300">
                            <Badge variant="secondary">{claim.pending}</Badge>
                          </TableCell>
                          <TableCell className="dark:text-gray-300">
                            <Badge variant="destructive">{claim.rejected}</Badge>
                          </TableCell>
                          <TableCell className="dark:text-gray-300">
                            <div className="flex items-center space-x-2">
                              <span>{((claim.approved / claim.claims) * 100).toFixed(1)}%</span>
                              <div className="w-16 bg-gray-200 rounded-full h-2">
                                <div
                                  className="bg-green-600 h-2 rounded-full"
                                  style={{ width: `${(claim.approved / claim.claims) * 100}%` }}
                                ></div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="dark:text-gray-300">₦{(claim.amount / 1000000).toFixed(1)}M</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>

              {/* Quick Reports */}
              <Card className="dark:bg-gray-800 dark:border-gray-700">
                <CardHeader>
                  <CardTitle className="text-gray-900 dark:text-white">Quick Reports</CardTitle>
                  <CardDescription className="text-gray-600 dark:text-gray-300">
                    Generate and download common reports
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
                      <Users className="h-6 w-6" />
                      <span className="text-sm">Patient Report</span>
                    </Button>
                    <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
                      <CreditCard className="h-6 w-6" />
                      <span className="text-sm">Financial Report</span>
                    </Button>
                    <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
                      <Pill className="h-6 w-6" />
                      <span className="text-sm">Pharmacy Report</span>
                    </Button>
                    <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
                      <Bed className="h-6 w-6" />
                      <span className="text-sm">Occupancy Report</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </main>
      </div>
    </div>
  )
}
